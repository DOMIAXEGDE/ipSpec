# ipLab.py
# Python 3.12.10
# A multi-language, plugin-driven, command-line development environment.
# Supports: C, C++, PHP, HTML/CSS/JS, Python, Perl, and SQL DBs.

import os
import json
import subprocess
import shutil
import importlib.util
import sys

# --- Constants ---
PROJECT_CONFIG_FILE = "ipLab.json"
SOURCE_DIR = "src"
BINARY_DIR = "bin"
WEB_DIR = "public"
DB_DIR = "database"
PLUGIN_DIR = "plugins"

# --- Utility Functions ---

def clear_screen():
    """Clears the terminal screen."""
    os.system('cls' if os.name == 'nt' else 'clear')

def display_header(title):
    """Displays a formatted header."""
    clear_screen()
    print("=" * 80)
    print(f"| {'iPLab Multi-Language Development Environment'.center(76)} |")
    print(f"| {title.center(76)} |")
    print("=" * 80)
    print()

def get_user_input(prompt, required=True):
    """Gets input from the user, with an option to make it required."""
    while True:
        user_input = input(f"> {prompt}: ").strip()
        if user_input or not required:
            return user_input
        print("! Error: This field is required.")

def display_message(message, is_error=False):
    """Displays a status message or an error."""
    prefix = "! Error:" if is_error else "* Success:"
    print(f"\n{prefix} {message}")
    input("\nPress Enter to continue...")

# --- Plugin Management ---

def load_plugins():
    """Loads all available language plugins from the plugin directory."""
    plugins = {}
    if not os.path.isdir(PLUGIN_DIR):
        print(f"! Warning: Plugin directory '{PLUGIN_DIR}' not found.")
        return plugins

    for filename in os.listdir(PLUGIN_DIR):
        # --- FIX ---
        # Skip the base_plugin.py file as it's a template, not a loadable plugin.
        if filename == "base_plugin.py":
            continue

        if filename.endswith("_plugin.py"):
            plugin_name = filename.replace("_plugin.py", "")
            try:
                module_name = f"{PLUGIN_DIR}.{plugin_name}_plugin"
                spec = importlib.util.spec_from_file_location(module_name, os.path.join(PLUGIN_DIR, filename))
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                plugins[plugin_name] = module.Plugin()
                print(f"  - Loaded plugin: {plugins[plugin_name].language_name}")
            except Exception as e:
                print(f"! Error loading plugin '{plugin_name}': {e}")
    return plugins

# --- Project Management ---

def create_project(plugins):
    """Guides the user through creating a new multi-language project."""
    display_header("Create New Project")
    project_name = get_user_input("Enter project name")
    project_dir = os.path.join(os.getcwd(), project_name)

    if os.path.exists(project_dir):
        display_message(f"Project directory '{project_name}' already exists.", is_error=True)
        return

    print("\nAvailable Language Profiles:")
    plugin_list = list(plugins.values())
    for i, plugin in enumerate(plugin_list):
        print(f"  [{i+1}] {plugin.language_name}")

    choices_str = get_user_input("Select languages to activate (e.g., 1 3 4)")
    selected_indices = [int(i) - 1 for i in choices_str.split()]

    project_data = {
        "projectName": project_name,
        "activeLanguages": [],
        "languageSettings": {}
    }

    try:
        os.makedirs(project_dir)
        # Create common directories
        os.makedirs(os.path.join(project_dir, SOURCE_DIR), exist_ok=True)
        os.makedirs(os.path.join(project_dir, BINARY_DIR), exist_ok=True)

        for i in selected_indices:
            if 0 <= i < len(plugin_list):
                plugin = plugin_list[i]
                lang_key = plugin.language_key
                project_data["activeLanguages"].append(lang_key)
                project_data["languageSettings"][lang_key] = plugin.get_default_settings()
                
                # Create language-specific directories and default files
                plugin.setup_project_structure(project_dir)
                plugin.create_default_file(project_dir, project_name)

        config_path = os.path.join(project_dir, PROJECT_CONFIG_FILE)
        with open(config_path, 'w') as f:
            json.dump(project_data, f, indent=4)

        display_message(f"Project '{project_name}' created successfully.")
        load_project(plugins, project_dir)

    except (OSError, ValueError) as e:
        display_message(f"Could not create project. {e}", is_error=True)


def load_project(plugins, project_path=None):
    """Loads an existing project."""
    display_header("Load Project")
    if not project_path:
        project_path = get_user_input("Enter path to project directory")

    config_path = os.path.join(project_path, PROJECT_CONFIG_FILE)

    if not os.path.isdir(project_path) or not os.path.isfile(config_path):
        display_message(f"Invalid project directory or missing '{PROJECT_CONFIG_FILE}'.", is_error=True)
        return

    try:
        with open(config_path, 'r') as f:
            project_data = json.load(f)
        project_management_menu(plugins, project_path, project_data)
    except (json.JSONDecodeError, KeyError) as e:
        display_message(f"Failed to load project configuration. {e}", is_error=True)

def save_project(project_path, project_data):
    """Saves the current project configuration."""
    config_path = os.path.join(project_path, PROJECT_CONFIG_FILE)
    try:
        with open(config_path, 'w') as f:
            json.dump(project_data, f, indent=4)
        return True
    except IOError as e:
        display_message(f"Could not save project config. {e}", is_error=True)
        return False

# --- Core Operations (Delegated to Plugins) ---

def compile_code(plugins, project_path, project_data):
    """Menu to select a language to compile."""
    display_header("Compile Code")
    
    active_plugins = [p for k, p in plugins.items() if k in project_data['activeLanguages'] and hasattr(p, 'compile')]
    if not active_plugins:
        display_message("No active languages in this project support compilation.", is_error=True)
        return

    print("Select a language to compile:")
    for i, plugin in enumerate(active_plugins):
        print(f"  [{i+1}] {plugin.language_name}")
    
    try:
        choice = int(get_user_input("Choose an option")) - 1
        if 0 <= choice < len(active_plugins):
            selected_plugin = active_plugins[choice]
            selected_plugin.compile(project_path, project_data['languageSettings'][selected_plugin.language_key])
        else:
            display_message("Invalid selection.", is_error=True)
    except ValueError:
        display_message("Invalid input.", is_error=True)

def run_code(plugins, project_path, project_data):
    """Menu to select a language to run."""
    display_header("Run Code / Start Server")

    active_plugins = [p for k, p in plugins.items() if k in project_data['activeLanguages'] and hasattr(p, 'run')]
    if not active_plugins:
        display_message("No active languages in this project are runnable.", is_error=True)
        return

    print("Select code to run or server to start:")
    for i, plugin in enumerate(active_plugins):
        print(f"  [{i+1}] {plugin.language_name}")

    try:
        choice = int(get_user_input("Choose an option")) - 1
        if 0 <= choice < len(active_plugins):
            selected_plugin = active_plugins[choice]
            settings = project_data['languageSettings'].get(selected_plugin.language_key, {})
            selected_plugin.run(project_path, settings)
        else:
            display_message("Invalid selection.", is_error=True)
    except ValueError:
        display_message("Invalid input.", is_error=True)

def manage_settings(plugins, project_path, project_data):
    """Menu to manage language-specific settings."""
    display_header("Manage Language Settings")

    active_plugins = [p for k, p in plugins.items() if k in project_data['activeLanguages'] and hasattr(p, 'manage_settings')]
    if not active_plugins:
        display_message("No active languages have configurable settings.", is_error=True)
        return

    print("Select a language to configure:")
    for i, plugin in enumerate(active_plugins):
        print(f"  [{i+1}] {plugin.language_name}")

    try:
        choice = int(get_user_input("Choose an option")) - 1
        if 0 <= choice < len(active_plugins):
            selected_plugin = active_plugins[choice]
            lang_key = selected_plugin.language_key
            
            # Pass the specific settings for that language to the plugin
            new_settings = selected_plugin.manage_settings(project_data['languageSettings'][lang_key])
            
            # Update the project data with the new settings
            project_data['languageSettings'][lang_key] = new_settings
            if save_project(project_path, project_data):
                display_message(f"{selected_plugin.language_name} settings updated.")
        else:
            display_message("Invalid selection.", is_error=True)
    except ValueError:
        display_message("Invalid input.", is_error=True)

# --- Menus ---

def project_management_menu(plugins, project_path, project_data):
    """Main menu for an opened project."""
    while True:
        active_langs = ", ".join([plugins[k].language_name for k in project_data['activeLanguages'] if k in plugins])
        display_header(f"Project: {project_data['projectName']}")
        print(f"Active Languages: {active_langs}\n")
        
        print("  [1] Compile Code (for C, C++, etc.)")
        print("  [2] Run Code / Start Server (for Python, PHP, etc.)")
        print("  [3] Manage Language Settings (Compiler flags, etc.)")
        print("  [4] Open Project Folder")
        print("  [5] Close Project")

        choice = get_user_input("Choose an option")
        if choice == '1':
            compile_code(plugins, project_path, project_data)
        elif choice == '2':
            run_code(plugins, project_path, project_data)
        elif choice == '3':
            manage_settings(plugins, project_path, project_data)
        elif choice == '4':
            display_header("Opening Project Folder")
            print(f"Path: {project_path}")
            if os.name == 'nt':
                os.startfile(project_path)
            elif sys.platform == 'darwin':
                subprocess.Popen(['open', project_path])
            else:
                subprocess.Popen(['xdg-open', project_path])
            display_message("Project folder opened in file explorer.")
        elif choice == '5':
            break
        else:
            display_message("Invalid option.", is_error=True)

def main_menu(plugins):
    """The main entry point menu of the application."""
    while True:
        display_header("Main Menu")
        print("  [1] Create New Project")
        print("  [2] Load Existing Project")
        print("  [q] Quit")

        choice = get_user_input("Choose an option")
        if choice == '1':
            create_project(plugins)
        elif choice == '2':
            load_project(plugins)
        elif choice.lower() == 'q':
            clear_screen()
            print("Exiting iPLab Environment. Goodbye!")
            break
        else:
            display_message("Invalid option.", is_error=True)

# --- Application Start ---

if __name__ == "__main__":
    # Create plugin directory if it doesn't exist
    if not os.path.isdir(PLUGIN_DIR):
        os.makedirs(PLUGIN_DIR)
        print(f"Created plugin directory: '{PLUGIN_DIR}'")
        print("Please add language plugin files to this directory.")
    
    print("Loading iPLab plugins...")
    loaded_plugins = load_plugins()
    if not loaded_plugins:
        print("\n! CRITICAL: No plugins found. Please create plugin files in the 'plugins' directory.")
        input("Press Enter to exit.")
    else:
        print(f"\nSuccessfully loaded {len(loaded_plugins)} plugins.")
        input("Press Enter to continue to the main menu...")
        main_menu(loaded_plugins)
