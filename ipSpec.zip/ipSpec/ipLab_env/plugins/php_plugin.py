# plugins/php_plugin.py
# Plugin for PHP (as a web server).

import os
import shutil
import subprocess
import sys
from .base_plugin import BasePlugin
from ipLab import display_header, get_user_input, display_message

class Plugin(BasePlugin):
    language_key = "php"
    language_name = "PHP"

    def get_default_settings(self):
        return {
            "php_executable": "php",
            "host": "localhost",
            "port": 8000
        }

    def setup_project_structure(self, project_path):
        os.makedirs(os.path.join(project_path, "public"), exist_ok=True)

    def create_default_file(self, project_path, project_name):
        content = f"""<!DOCTYPE html>
<html>
<head>
    <title>{project_name}</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Hello from the PHP component of '{project_name}'!</h1>
    <p>Today's date is <?php echo date('Y-m-d H:i:s'); ?>.</p>
    <script src="script.js"></script>
</body>
</html>
"""
        with open(os.path.join(project_path, "public", "index.php"), "w") as f:
            f.write(content)

    def run(self, project_path, settings):
        display_header("Run PHP Development Server")
        php_exec = settings.get('php_executable', 'php')
        if not shutil.which(php_exec):
            display_message(f"PHP executable '{php_exec}' not found.", is_error=True)
            return

        host = settings.get('host', 'localhost')
        port = settings.get('port', 8000)
        web_dir = os.path.join(project_path, "public")
        
        command = [php_exec, '-S', f'{host}:{port}', '-t', web_dir]
        
        print(f"Starting PHP server at http://{host}:{port}")
        print(f"Document root: {web_dir}")
        print("Press Ctrl+C in this terminal to stop the server.")
        
        try:
            # We run this in the foreground as it's a server process
            subprocess.run(command)
        except KeyboardInterrupt:
            display_message("\nPHP server stopped by user.")
        except Exception as e:
            display_message(f"Failed to start PHP server. {e}", is_error=True)

    def manage_settings(self, current_settings):
        display_header("Manage PHP Settings")
        print(f"1. Host: {current_settings['host']}")
        print(f"2. Port: {current_settings['port']}")

        new_host = get_user_input("Enter new host or press Enter to keep", required=False)
        if new_host:
            current_settings['host'] = new_host

        new_port = get_user_input("Enter new port or press Enter to keep", required=False)
        if new_port:
            try:
                current_settings['port'] = int(new_port)
            except ValueError:
                print("! Invalid port, keeping original.")
        
        return current_settings
