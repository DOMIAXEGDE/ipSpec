# plugins/c_plugin.py
# Plugin for the C language.

import os
import shutil
import subprocess
from .base_plugin import BasePlugin
from ipLab import display_header, get_user_input, display_message

class Plugin(BasePlugin):
    language_key = "c"
    language_name = "C"

    def get_default_settings(self):
        return {
            "compiler": "gcc",
            "sourceFiles": ["main.c"],
            "outputExecutable": "program",
            "compilationFlags": ["-Wall", "-Wextra"]
        }

    def setup_project_structure(self, project_path):
        # Uses the common 'src' and 'bin' directories
        pass

    def create_default_file(self, project_path, project_name):
        content = f"""#include <stdio.h>

int main() {{
    printf("Hello from the C component of '{project_name}'!\\n");
    return 0;
}}
"""
        with open(os.path.join(project_path, "src", "main.c"), "w") as f:
            f.write(content)

    def compile(self, project_path, settings):
        display_header(f"Compile: {self.language_name}")
        compiler = settings.get('compiler', 'gcc')
        if not shutil.which(compiler):
            display_message(f"Compiler '{compiler}' not found in system PATH.", is_error=True)
            return

        src_dir = os.path.join(project_path, "src")
        bin_dir = os.path.join(project_path, "bin")
        output_name = settings.get('outputExecutable', 'program_c')
        output_path = os.path.join(bin_dir, output_name)

        source_files = [os.path.join(src_dir, f) for f in settings['sourceFiles'] if f.endswith('.c')]
        flags = settings.get('compilationFlags', [])
        command = [compiler] + flags + ['-o', output_path] + source_files

        print(f"Executing: {' '.join(command)}")
        result = subprocess.run(command, capture_output=True, text=True)

        if result.returncode == 0:
            display_message(f"C compilation successful! Executable at '{output_path}'")
        else:
            print("\n--- C COMPILATION FAILED ---\n", result.stderr)
            display_message("C compilation failed.", is_error=True)

    def manage_settings(self, current_settings):
        display_header("Manage C Settings")
        print(f"1. Compiler: {current_settings['compiler']}")
        print(f"2. Flags: {' '.join(current_settings['compilationFlags'])}")
        
        new_compiler = get_user_input(f"Enter new compiler or press Enter to keep '{current_settings['compiler']}'", required=False)
        if new_compiler:
            current_settings['compiler'] = new_compiler

        new_flags_str = get_user_input("Enter new flags (space-separated) or press Enter to keep", required=False)
        if new_flags_str:
            current_settings['compilationFlags'] = new_flags_str.split()
            
        return current_settings
