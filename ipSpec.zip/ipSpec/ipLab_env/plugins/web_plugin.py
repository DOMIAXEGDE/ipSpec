# plugins/web_plugin.py
# Plugin for basic web development (HTML, CSS, JS).

import os
import sys
import subprocess
from .base_plugin import BasePlugin
from ipLab import display_message

class Plugin(BasePlugin):
    language_key = "web"
    language_name = "HTML/CSS/JS"

    def get_default_settings(self):
        return {} # No specific settings needed

    def setup_project_structure(self, project_path):
        os.makedirs(os.path.join(project_path, "public"), exist_ok=True)

    def create_default_file(self, project_path, project_name):
        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{project_name}</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Hello from the Web component of '{project_name}'!</h1>
    <p>This is a static site.</p>
    <button id="myButton">Click Me</button>
    <script src="script.js"></script>
</body>
</html>
"""
        css_content = """body { font-family: sans-serif; background-color: #f0f0f0; }
h1 { color: #333; }
"""
        js_content = """document.getElementById('myButton').addEventListener('click', () => {
    alert('Hello from JavaScript!');
});
"""
        web_dir = os.path.join(project_path, "public")
        with open(os.path.join(web_dir, "index.html"), "w") as f:
            f.write(html_content)
        with open(os.path.join(web_dir, "style.css"), "w") as f:
            f.write(css_content)
        with open(os.path.join(web_dir, "script.js"), "w") as f:
            f.write(js_content)

    def run(self, project_path, settings):
        """Opens the index.html file in the default web browser."""
        file_path = os.path.join(project_path, "public", "index.html")
        if not os.path.exists(file_path):
            display_message("index.html not found.", is_error=True)
            return
        
        try:
            if sys.platform == 'win32':
                os.startfile(file_path)
            elif sys.platform == 'darwin':
                subprocess.Popen(['open', file_path])
            else:
                subprocess.Popen(['xdg-open', file_path])
            display_message("Opened index.html in your default browser.")
        except Exception as e:
            display_message(f"Could not open browser. {e}", is_error=True)
