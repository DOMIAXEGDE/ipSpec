# plugins/perl_plugin.py
# Plugin for Perl.

import os
import sys
import shutil
import subprocess
from .base_plugin import BasePlugin
from ipLab import display_header, get_user_input, display_message

class Plugin(BasePlugin):
    language_key = "perl"
    language_name = "Perl"

    def get_default_settings(self):
        return {
            "entry_point": "main.pl"
        }

    def setup_project_structure(self, project_path):
        pass

    def create_default_file(self, project_path, project_name):
        content = f"""#!/usr/bin/perl
use strict;
use warnings;

print "Hello from the Perl component of '{project_name}'!\\n";
"""
        with open(os.path.join(project_path, "src", "main.pl"), "w") as f:
            f.write(content)

    def run(self, project_path, settings):
        display_header("Run Perl Script")
        perl_exec = "perl"
        if not shutil.which(perl_exec):
            display_message("Perl executable not found.", is_error=True)
            return

        entry_point = settings.get("entry_point", "main.pl")
        script_path = os.path.join(project_path, "src", entry_point)

        if not os.path.exists(script_path):
            display_message(f"Entry point '{entry_point}' not found.", is_error=True)
            return

        command = [perl_exec, script_path]
        print(f"Executing: {' '.join(command)}")
        
        if os.name == 'nt':
            subprocess.Popen(['start', 'cmd', '/k'] + command, shell=True)
        else:
            subprocess.Popen(['gnome-terminal', '--'] + command)
        
        display_message(f"Launched '{entry_point}' in a new terminal.")

    def manage_settings(self, current_settings):
        display_header("Manage Perl Settings")
        print(f"1. Entry Point Script: {current_settings['entry_point']}")
        new_entry = get_user_input("Enter new entry point script or press Enter to keep", required=False)
        if new_entry:
            current_settings['entry_point'] = new_entry
        return current_settings
