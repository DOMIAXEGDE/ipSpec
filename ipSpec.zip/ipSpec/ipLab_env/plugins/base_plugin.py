# plugins/base_plugin.py
# Abstract base class for all iPLab language plugins.
# Defines the complete interface required for a plugin to integrate with the environment.

import os
import shutil
from abc import ABC, abstractmethod

class BasePlugin(ABC):
    """
    Defines the interface that all language plugins must implement.

    This abstract class ensures that every plugin provides a consistent set of
    functionalities that the main iPLab application can rely on for project
    creation, management, compilation, and execution.
    """

    # --- Abstract Properties (Must be implemented by all plugins) ---

    @property
    @abstractmethod
    def language_key(self) -> str:
        """
        A unique, short, lowercase string key for the language.
        e.g., 'c', 'python', 'cpp'
        """
        pass

    @property
    @abstractmethod
    def language_name(self) -> str:
        """
        The user-friendly, display name of the language.
        e.g., 'C', 'Python', 'C++'
        """
        pass

    # --- Abstract Methods (Must be implemented by all plugins) ---

    @abstractmethod
    def get_default_settings(self) -> dict:
        """
        Return a dictionary of default settings for this language.
        These settings will be stored in the project's ipLab.json file.

        Returns:
            dict: A dictionary containing default configuration values.
        """
        pass

    @abstractmethod
    def setup_project_structure(self, project_path: str):
        """
        Create any language-specific directories needed for a new project.
        Common directories like 'src' and 'bin' are created by the core app.
        This method is for special cases, like a 'public' dir for web projects.

        Args:
            project_path (str): The absolute path to the project's root directory.
        """
        pass

    @abstractmethod
    def create_default_file(self, project_path: str, project_name: str):
        """
        Create a default 'hello world' or index file for the language.
        This provides the user with a starting point immediately after project creation.

        Args:
            project_path (str): The absolute path to the project's root directory.
            project_name (str): The name of the project.
        """
        pass

    # --- Optional Methods (Can be overridden by plugins if needed) ---

    def compile(self, project_path: str, settings: dict):
        """
        Compile the source code for the project.
        This method should be implemented by plugins for compiled languages (C, C++).

        Args:
            project_path (str): The absolute path to the project's root directory.
            settings (dict): The language-specific settings from ipLab.json.
        """
        raise NotImplementedError(f"Compilation is not supported by the {self.language_name} plugin.")

    def run(self, project_path: str, settings: dict):
        """
        Run the compiled code or execute the script.
        For web languages, this might start a development server.

        Args:
            project_path (str): The absolute path to the project's root directory.
            settings (dict): The language-specific settings from ipLab.json.
        """
        raise NotImplementedError(f"Direct execution is not supported by the {self.language_name} plugin.")

    def clean(self, project_path: str, settings: dict):
        """
        Remove build artifacts, binaries, and intermediate files.
        This is useful for compiled languages to clean the 'bin' directory.

        Args:
            project_path (str): The absolute path to the project's root directory.
            settings (dict): The language-specific settings from ipLab.json.
        """
        print(f"No specific 'clean' operation is defined for {self.language_name}.")
        # Default implementation does nothing, plugins must override.

    def manage_settings(self, current_settings: dict) -> dict:
        """
        Display a menu to the user for modifying language-specific settings.
        This method is responsible for gathering user input and updating the settings dictionary.

        Args:
            current_settings (dict): The current settings for this language.

        Returns:
            dict: The updated settings dictionary.
        """
        print(f"No specific settings are available to manage for {self.language_name}.")
        return current_settings

    # --- Static Utility Methods (Helpers for all plugins) ---

    @staticmethod
    def find_executable(name: str) -> str | None:
        """
        A static helper method to find an executable in the system's PATH.
        This centralizes the check and reduces code duplication in plugins.

        Args:
            name (str): The name of the executable to find (e.g., 'gcc', 'python').

        Returns:
            str | None: The full path to the executable, or None if not found.
        """
        return shutil.which(name)
