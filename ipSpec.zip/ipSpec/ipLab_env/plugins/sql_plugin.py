# plugins/sql_plugin.py
# Plugin for managing SQL database scripts.

import os
from .base_plugin import BasePlugin
from ipLab import display_header, display_message

class Plugin(BasePlugin):
    language_key = "sql"
    language_name = "SQL (MariaDB/MySQL)"

    def get_default_settings(self):
        return {
            "schema_file": "schema.sql",
            "data_file": "data.sql"
        }

    def setup_project_structure(self, project_path):
        os.makedirs(os.path.join(project_path, "database"), exist_ok=True)

    def create_default_file(self, project_path, project_name):
        schema_content = f"""-- Database schema for {project_name}
-- Example:
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""
        data_content = f"""-- Initial data for {project_name}
-- Example:
-- INSERT INTO users (username) VALUES ('admin');
"""
        db_dir = os.path.join(project_path, "database")
        with open(os.path.join(db_dir, "schema.sql"), "w") as f:
            f.write(schema_content)
        with open(os.path.join(db_dir, "data.sql"), "w") as f:
            f.write(data_content)

    def run(self, project_path, settings):
        display_header("Manage Database")
        db_dir = os.path.join(project_path, "database")
        print("This plugin does not directly execute SQL.")
        print("Use a command-line client like 'mysql' or 'mariadb' to import these files.")
        print("\nExample commands:")
        print(f"  mysql -u your_user -p your_database < {os.path.join(db_dir, 'schema.sql')}")
        print(f"  mysql -u your_user -p your_database < {os.path.join(db_dir, 'data.sql')}")
        display_message("Manual import required.", is_error=False)
